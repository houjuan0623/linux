linux-0.96
==========
https://www.kernel.org/pub/linux/kernel/Historic/old-versions/
